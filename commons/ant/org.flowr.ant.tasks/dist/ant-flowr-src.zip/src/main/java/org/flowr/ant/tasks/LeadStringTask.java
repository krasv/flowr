/**
 * DB Systel GmbH / i.S.A. Dresden GmbH & Co. KG (c) 2010
 */
package org.flowr.ant.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.PropertyHelper;

/**
 * Ant task evaluating the text part after a specified separator.
 *
 * @author SvenKrause
 *
 */
public class LeadStringTask extends AbstractSeparatorbasedStringTask {

	private boolean last;

	/**
	 * @param last
	 *        the last to set
	 */
	public void setLast(boolean last) {
		this.last = last;
	}

	@Override
	public void init() throws BuildException {
		super.init();
		last = false;
	}

	@Override
	public void execute() throws BuildException {
		validate();

		PropertyHelper ph = PropertyHelper.getPropertyHelper(this.getProject());
		int indexOf =  last ? text.lastIndexOf(separator) : text.indexOf(separator);
		if (indexOf != -1) {
			String lead = text.substring(0, indexOf);
			ph.setProperty("", propName, lead, true);
		} else {
			ph.setProperty("", propName, text, true);
		}
	}

}
