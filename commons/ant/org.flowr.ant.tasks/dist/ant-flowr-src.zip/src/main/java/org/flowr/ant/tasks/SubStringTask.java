/**
 * DB Systel GmbH / i.S.A. Dresden GmbH & Co. KG (c) 2010
 */
package org.flowr.ant.tasks;

import org.apache.tools.ant.BuildException;
import org.apache.tools.ant.PropertyHelper;

/**
 * Ant task evaluating the text part after a specified separator.
 * 
 * @author SvenKrause
 * 
 */
public class SubStringTask extends AbstractStringTask {

   private int begin;
   private int end;

   @Override
   public void init() throws BuildException {
      super.init();
      begin = 0;
      end = -1;
   }

   /**
    * @param begin the begin to set
    */
   public void setBegin(int begin) {
      this.begin = begin;
   }

   /**
    * @param end the end to set
    */
   public void setEnd(int end) {
      this.end = end;
   }

   @Override
   protected void validate() {
      if (end < 0 && text != null) {
         end = text.length();
      }
      super.validate();
      validate(begin >= 0, "begin can not be less then zero");
      validate(begin <= end, "begin can not be greater than end");
      validate(begin <= text.length(), "begin can not be greater that text length");
      validate(end <= text.length(), "end can not be greater that text length");
   }

   @Override
   public void execute() throws BuildException {
      validate();

      PropertyHelper ph = PropertyHelper.getPropertyHelper(this.getProject());
      ph.setProperty("", propName, text.substring(begin, end), true);
   }

}
